function salir() {
  location.replace("https://www.w3schools.com");
}
