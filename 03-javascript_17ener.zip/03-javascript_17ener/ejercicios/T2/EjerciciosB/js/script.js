function ejercicio8() {
  let cambiarHtml = prompt("Ingresa un nombre para el HTML: ");
  document.title = cambiarHtml;
  let cambiarBackground = confirm("¿Quieres cambiar el fondo de la Web?");
  if (cambiarBackground == true) {
    document.body.style.backgroundColor = "black";
  }
}

function ejecEjercicio9() {
  let textEjercicio9 = `Tamaño del window: ${window.innerWidth} X ${window.innerHeight} px. <br/>Tamño del HTML: ${document.body.scrollWidth} X ${document.body.scrollHeight} px.`;
  document.querySelector("#mostrador").innerHTML = textEjercicio9;
}

function ejecEjercicio11() {
  let abrirVentana = window.open(
    "ventana.html",
    "_blank",
    `width=700,
    height=500`
  );
  abrirVentana.onload = function () {
    abrirVentana.document.querySelector(
      "#seccion_ventana"
    ).innerHTML = `Tamaño del window: ${abrirVentana.innerWidth} X ${abrirVentana.innerHeight} px.`;
  };
}

function cerrarVentana() {
  window.close();
}
