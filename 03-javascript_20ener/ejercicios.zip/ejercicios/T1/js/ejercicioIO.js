let mensaje = prompt("Cuando se ejecuta el JavaScript?");
console.log(mensaje);
alert(mensaje);
document.querySelector("#mostrar").innerHTML = mensaje;
