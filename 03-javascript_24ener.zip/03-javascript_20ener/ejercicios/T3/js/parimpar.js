let div_st1 = `<div class="alert alert-success">`;

let result;
let resultado;
/* necesito acceder a lo qu el usuario ingrese para eso debo acceder al <input> por medio del id o class, y lo guardo en una constante */
const num = document.querySelector("#input_numero");
const btn_01 = document.querySelector("#btn_ejer01");
const muestra_01 = document.querySelector("#mostrar_01");
const btn_borrar = document.querySelector("#btn_borra01");

/* btn_01.onclick = parImpar; ANTES cuando la función no era constante osea una ArrowFunction, esto se podia ejecutar, AHORA no

function parImpar() {  Esto al pasarlo a Arrow Function */
const parImpar = () => {
  let n = num.value;
  console.log(typeof n);
  n = Number(n.replace(",", "."));
  console.log(typeof n);

  if (isNaN(n) || n == "") {
    //El caracter 2 y el numero 2 para el doble igual... ambos son iguales
    resultado = `<div class="alert alert-danger">No puedo operar</div>`;
    document.querySelector("#mostrar_01").style = "opacity: 100%;";
  } else {
    result = n % 2;
    /* se puede reducir a su condicion declarada como cierta y si no el else 
   condicion_a_evaluar? accion_a_ejecutar: (sino) accion_descarte;*/
    /* if (result !== 0) {
      resultado = `<div class="alert alert-success">El valor introducido es un número impar, concretamente el ${n} <br/></div>`;
    } else {
      resultado = `<div class="alert alert-success">El valor introducido es un número par, concretamente el ${n} <br/></div>`;
   } */
    result !== 0
      ? ((resultado = `<div class="alert alert-success">El valor introducido es un número impar, concretamente el ${n} <br/></div>`),
        (document.querySelector("#mostrar_01").style = "opacity: 100%;"))
      : ((resultado = `<div class="alert alert-success">El valor introducido es un número par, concretamente el ${n} <br/></div>`),
        (document.querySelector("#mostrar_01").style = "opacity: 100%;"));
  }
  muestra_01.innerHTML = resultado;
  num.value = ``;
};
/* function borrar() {
 num.value = ``;
 muestra_01 = ``;
} */
const borrar = () => {
  num.value = ``;
  muestra_01.innerHTML = ``;
  document.querySelector("#mostrar_01").style = "";
};

num.addEventListener("keypress", function (event) {
  if (event.key === `Enter`) {
    btn_01.onclick = parImpar();
  }
});
btn_01.onclick = parImpar; //pierde los parentecis para ser llamada, cuando se llama con onclick u otro evento.
btn_borrar.onclick = borrar;

const num_02 = document.querySelector("#input_num_02");
const btn_02 = document.querySelector("#btn_ejer02");
const muestra_02 = document.querySelector("#mostrar_02");
const btn_borr_02 = document.querySelector("#btn_borra02");
function ejercicioDos() {
  if (Number(num_02.value) == 12) {
    muestra_02.innerHTML = `<div class="alert alert-success">Bien has acertado.</div>`;
  } else {
    muestra_02.innerHTML = `<div class="alert alert-danger">No has acertado, intenta denuevo.</div>`;
    alert("No has acertado!");
    num_02.value = ``;
  }
}
const borrar_02 = () => {
  num_02.value = ``;
  muestra_02.innerHTML = ``;
};
btn_02.onclick = ejercicioDos;
btn_borr_02.onclick = borrar_02;

const num_03 = document.querySelector("#input_num_03");
const btn_03 = document.querySelector("#btn_ejer03");
const muestra_03 = document.querySelector("#mostrar_03");
const btn_borr_03 = document.querySelector("#btn_borra03");
function ejercicioTres() {
  let ejer03_iva = Number(num_03.value) * 0.21;
  console.log(ejer03_iva);
  muestra_03.innerHTML = `<div class="alert alert-success">Precio sin IVA ${Number(
    num_03.value
  )}<br />
  IVA ${ejer03_iva}<br />
  Precio con IVA ${Number(num_03.value) + ejer03_iva}</div>`;
}

btn_03.onclick = ejercicioTres;
const borrar_03 = () => {
  num_03.value = ``;
  muestra_03.innerHTML = ``;
};
btn_borr_03.onclick = borrar_03;

/* MARK: EJ4
 */
const num_04 = document.querySelector("#input_num_04");
const num_04b = document.querySelector("#input_num_04b");
const btn_04 = document.querySelector("#btn_ejer04");
const muestra_04 = document.querySelector("#mostrar_04");
const btn_borr_04 = document.querySelector("#btn_borra04");
let formulario = document.forms["formulario_a"];
let selector = formulario["operaciones_list"];
let indexSeleccionado;

const borrar_04 = () => {
  num_04.value = ``;
  num_04b.value = ``;
  muestra_04.innerHTML = ``;
};
function ejercicioCuatro() {
  /* borrar_04(); */
  indexSeleccionado = selector.selectedIndex;
  console.log(indexSeleccionado);
  console.log(num_04.value);
  switch (indexSeleccionado) {
    case 1:
      muestra_04.innerHTML = `${div_st1}${
        Number(num_04.value) + Number(num_04b.value)
      }</div>`;
      break;
    case 2:
      muestra_04.innerHTML = `${div_st1}${
        Number(num_04.value) - Number(num_04b.value)
      }</div>`;
      break;
    case 3:
      muestra_04.innerHTML = `${div_st1}${
        Number(num_04.value) / Number(num_04b.value)
      }</div>`;
      break;
    case 4:
      muestra_04.innerHTML = `${div_st1}${
        Number(num_04.value) * Number(num_04b.value)
      }</div>`;
      break;
    case 5:
      muestra_04.innerHTML = `${div_st1}${
        Number(num_04.value) % Number(num_04b.value)
      }</div>`;
      break;
    default:
      borrar_04();
  }
}
btn_04.onclick = ejercicioCuatro;
btn_borr_04.onclick = borrar_04;
/* MARK: EJ5
 */
const num_05 = document.querySelector("#input_num_05");
const btn_05 = document.querySelector("#btn_ejer05");
const muestra_05 = document.querySelector("#mostrar_05");
const btn_borr_05 = document.querySelector("#btn_borra05");
const textoArray = [num_05.value];
function ejercicioCinco() {
  console.log(num_05.value);
  let i = 0;
  while (i < num_05.value) {
    textoArray[i] = `codi_producte ${i + 1}: ${
      Math.floor(Math.random() * 30000) + 1
    }<br />`;
    i++;
  }
  muestra_05.innerHTML = `${div_st1} ${textoArray}</div>`;
}
const borrar_05 = () => {
  num_05.value = ``;
  muestra_05.innerHTML = ``;
};
btn_05.onclick = ejercicioCinco;
btn_borr_05.onclick = borrar_05;
/* MARK:EJ6
 */
const muestra_06 = document.querySelector("#mostrar_06");
const a_ejer6 = document.querySelector("#hiper_datos");
const btn_borr_06 = document.querySelector("#btn_borra06");
var ow = window.outerWidth;
var oh = window.outerHeight;
var spx = screen.pixelDepth;
var w = window.innerWidth;
var h = window.innerHeight;
var diag = Math.sqrt(Math.pow(screen.height, 2) + Math.pow(screen.width, 2));
function ejercicioSeis() {
  muestra_06.innerHTML = `${div_st1} Outer Sizes: ${ow} x ${oh} <br/>Inner Sizes: ${w} x ${h} <br/>Pixel Deep: ${spx} <br/> Screen diagonal size: ${Math.floor(
    diag
  )}</div>`;
}
const borrar_06 = () => {
  muestra_06.innerHTML = ``;
};
a_ejer6.onclick = ejercicioSeis;
btn_borr_06.onclick = borrar_06;

/* MARK: EJ7
 */
let formulario2 = document.forms["formulario_b"];
let selector2 = formulario2["operaciones_listb"];
let indexSeleccionado2;
let btn_07 = document.querySelector("#btn_ejer07");
let btn_borr_07 = document.querySelector("#btn_borra07");
const borrar_07 = () => {
  document.body.style = ``;
};
function ejercicioSiete() {
  indexSeleccionado2 = selector2.selectedIndex;
  /*console.log(indexSeleccionado2); */
  switch (indexSeleccionado2) {
    case 1:
      document.body.style = `background-color: #A6427C`;
      break;
    case 2:
      document.body.style = `background-color: #CD899E`;
      break;
    case 3:
      document.body.style = `background-color: #DFB1B6`;
      break;
    case 4:
      document.body.style = `background-color: #F5EAE3`;
      break;
    default:
      document.body.style = ``;
      break;
  }
}
btn_07.onclick = ejercicioSiete;
btn_borr_07.onclick = borrar_07;
/* Pot Pourri = F5EAE3 
Cavern Pink = DFB1B6
Puce = CD899E
Rouge = A6427C */
